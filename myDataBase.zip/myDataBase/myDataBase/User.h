//
//  User.h
//  myDataBase
//
//  Created by Mac on 16/7/12.
//  Copyright © 2016年 Mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface User : NSObject
@property (nonatomic,strong) NSString *user_id;
@property (nonatomic,strong) NSString *name;
@property (nonatomic,strong) NSString *age;
@property (nonatomic,strong) NSString *sex;
@property (nonatomic,strong) NSString *height;
//@property (nonatomic,strong) NSArray *array;
//@property (nonatomic,strong) NSDictionary *dic;
//@property (nonatomic,strong) NSMutableArray *muArray;
//@property (nonatomic,strong) NSMutableDictionary *mudic;
//@property (nonatomic,strong) NSData *data;
//@property (nonatomic,strong) NSMutableData *muData;
//@property (nonatomic,assign) NSInteger index;
//@property (nonatomic,assign) float f;
//@property (nonatomic,assign) double d;
//@property (nonatomic,assign) char c;
//@property (nonatomic,assign) CGSize size;
@end
