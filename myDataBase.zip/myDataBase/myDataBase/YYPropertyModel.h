//
//  YYPropertyModel.h
//  myDataBase
//
//  Created by Loser on 2017/5/8.
//  Copyright © 2017年 Mac. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YYPropertyModel : NSObject
@property (nonatomic,strong) NSString *propertyName;
@property (nonatomic,strong) NSString *propertyType;
@end
