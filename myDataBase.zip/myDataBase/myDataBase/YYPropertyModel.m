//
//  YYPropertyModel.m
//  myDataBase
//
//  Created by Loser on 2017/5/8.
//  Copyright © 2017年 Mac. All rights reserved.
//

#import "YYPropertyModel.h"

@implementation YYPropertyModel

@end
