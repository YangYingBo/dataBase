//
//  books.h
//  RunTime
//
//  Created by Loser on 2017/7/6.
//  Copyright © 2017年 Loser. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol books <NSObject>
@end

@interface books : NSObject
@property (nonatomic,strong) NSString *blockName;
@end
