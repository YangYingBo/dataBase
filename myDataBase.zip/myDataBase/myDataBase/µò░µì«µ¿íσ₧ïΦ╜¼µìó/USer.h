//
//  USer.h
//  RunTime
//
//  Created by Loser on 2017/7/5.
//  Copyright © 2017年 Loser. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface USer : NSObject
@property (nonatomic,strong) NSString *name;
@property (nonatomic,strong) NSString *iphone;
@end
