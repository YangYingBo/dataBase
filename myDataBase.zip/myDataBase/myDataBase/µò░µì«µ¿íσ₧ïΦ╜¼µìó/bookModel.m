//
//  bookModel.m
//  RunTime
//
//  Created by Loser on 2017/7/6.
//  Copyright © 2017年 Loser. All rights reserved.
//

#import "bookModel.h"

@implementation bookModel

@end
