//
//  NSObject+BaseModel.h
//  RunTime
//
//  Created by Loser on 2017/7/5.
//  Copyright © 2017年 Loser. All rights reserved.
//

#import <Foundation/Foundation.h>
@interface NSObject (BaseModel)
+ (instancetype)modelWithDictionary:(NSDictionary *)dict;
@end

@protocol NSArrayModelProtocol <NSObject>
@end
@interface NSArray (arrayModelProtocol)<NSArrayModelProtocol>

@end
