//
//  Model.h
//  RunTime
//
//  Created by Loser on 2017/7/5.
//  Copyright © 2017年 Loser. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "USer.h"
#import "NSObject+BaseModel.h"
#import "books.h"
#import "bookModel.h"

@interface Model : NSObject
@property (nonatomic,strong) NSString *age;
@property (nonatomic,strong) NSString *height;
@property (nonatomic,assign) NSInteger witgh;
@property (nonatomic,strong) USer *user;
@property (nonatomic,strong) NSArray <NSArrayModelProtocol,books>*books;
@end
