//
//  NSObject+BaseModel.m
//  RunTime
//
//  Created by Loser on 2017/7/5.
//  Copyright © 2017年 Loser. All rights reserved.
//

#import "NSObject+BaseModel.h"
#import <objc/runtime.h>

@implementation NSObject (BaseModel)
+ (instancetype)modelWithDictionary:(NSDictionary *)dict
{
    id obj = [[self alloc] init];
//    NSLog(@"%@",NSStringFromClass([obj class]));
    unsigned int count = 0;
    objc_property_t *property = class_copyPropertyList(self, &count);
    
    for (NSInteger index = 0;index < count ; index ++) {
        const char *name = property_getName((property[index]));
        // 获取属性名
        NSString *protertyName = [NSString stringWithUTF8String:name];
        // 属性类型
        NSString *proteryType = [NSString stringWithUTF8String:property_getAttributes(property[index])];
//        NSLog(@"protertyName=====%@    proteryType=====%@",protertyName,proteryType);
        id value = dict[protertyName];
        
        if ([value isKindOfClass:[NSDictionary class]]) {
            NSRange range = [proteryType rangeOfString:@","];
            proteryType = [proteryType substringToIndex:range.location];
            if (proteryType.length>4) {
                proteryType = [proteryType substringWithRange:NSMakeRange(3, proteryType.length-4)];
            }
            Class modelClass = NSClassFromString(proteryType);
            
            if (modelClass) {
                value = [modelClass modelWithDictionary:value];
            }
            
        }
        
        //T@"NSArray<books><NSArrayModelProtocol>",&,N,V_books
        //T@"NSArray<NSArrayModelProtocol><books>",&,N,V_books
        //获取数组里面的对应的模型
        if ([value isKindOfClass:[NSArray class]]) {
            NSArray *proterys = [proteryType componentsSeparatedByString:@","];
            NSString *oneProteryString = [proterys firstObject];
            NSMutableArray *subProterys = [NSMutableArray arrayWithArray:[oneProteryString componentsSeparatedByString:@"<"]];
            [subProterys removeObjectAtIndex:0];
            NSString *classString;
            for (NSInteger index = 0; index < subProterys.count; index ++) {
                NSString *subString = subProterys[index];
                NSRange range = [subString rangeOfString:@">"];
                subString = [subString substringWithRange:NSMakeRange(0, range.location)];
                if (![subString isEqualToString:@"NSArrayModelProtocol"]) {
                    classString = subString;
                }
            }
//            NSLog(@"classStringclassString  %@",classString);
            Class modelClass = NSClassFromString(classString);
            NSMutableArray *classArray = [NSMutableArray array];
            if (modelClass) {
                
                for (NSDictionary *dic in value) {
                    id model = [modelClass modelWithDictionary:dic];
                    [classArray addObject:model];
                }
                value = classArray;
                
            }
            
        }
        
        if (value) {
            [obj setValue:value forKey:protertyName];
        }
    }
    
    return obj;
}




@end

@implementation NSArray (arrayModelProtocol)

@end
