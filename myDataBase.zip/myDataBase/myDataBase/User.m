//
//  User.m
//  myDataBase
//
//  Created by Mac on 16/7/12.
//  Copyright © 2016年 Mac. All rights reserved.
//

#import "User.h"

@implementation User

@end
