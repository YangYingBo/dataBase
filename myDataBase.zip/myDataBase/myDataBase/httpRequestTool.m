//
//  httpRequestTool.m
//  MVVM
//
//  Created by 求罩 on 16/4/8.
//  Copyright © 2016年 求罩. All rights reserved.
//


#import <UIKit/UIKit.h>
#import "httpRequestTool.h"
#import "AFNetworking.h"


@implementation httpRequestTool

+ (void)netRequestGetUrl:(NSString *)url parame:(id)parrame downLoadProgress:(void(^)(CGFloat progree))downLoadProgress success:(void(^)(id jsonDic))success failure:(void(^)(NSError *error))failure;
{
//    url = [url stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    
    AFHTTPSessionManager *manger = [[AFHTTPSessionManager alloc] init];
    manger.requestSerializer = [AFHTTPRequestSerializer serializer];
    manger.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"text/json", @"text/javascript", @"text/html", nil];
    
    [manger GET:url parameters:parrame progress:^(NSProgress * _Nonnull downloadProgress) {
        // 下载进度
        
        __block CGFloat download = downloadProgress.completedUnitCount/downloadProgress.totalUnitCount;
        if (downLoadProgress) {
            downLoadProgress(download);
        }
        
        NSLog(@"%lld",downloadProgress.completedUnitCount/downloadProgress.totalUnitCount);
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        if (success) {
            success(responseObject);
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        if (failure) {
            failure(error);
        }
    }];
}

+ (void)netRequestPostUrl:(NSString *)url parame:(id)parrame downLoadProgress:(void(^)(CGFloat progree))downLoadProgress success:(void(^)(id data))success failure:(void(^)(NSError *error))failure
{
    
    
    AFHTTPSessionManager *manger = [[AFHTTPSessionManager alloc] init];
    manger.requestSerializer = [AFHTTPRequestSerializer serializer];

    [manger POST:url parameters:parrame progress:^(NSProgress * _Nonnull uploadProgress) {
        // 下载进度
        __block CGFloat download = uploadProgress.completedUnitCount/uploadProgress.totalUnitCount;
        if (downLoadProgress) {
            downLoadProgress(download);
        }
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        if (success) {
            success(responseObject);
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        if (failure) {
            failure(error);
        }
    }];
}

+ (void)netRequestGetUrlBackXML:(NSString *)url parame:(id)parrame downLoadProgress:(void(^)(CGFloat progree))downLoadProgress success:(void(^)(id jsonDic))success failure:(void(^)(NSError *error))failure
{
    AFHTTPSessionManager *manger = [[AFHTTPSessionManager alloc] init];
    manger.responseSerializer = [AFXMLParserResponseSerializer serializer];
    manger.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"text/json", @"text/javascript", @"text/html", nil];

    [manger GET:url parameters:parrame progress:^(NSProgress * _Nonnull downloadProgress) {
        // 下载进度
        __block CGFloat download = downloadProgress.completedUnitCount/downloadProgress.totalUnitCount;
        if (downLoadProgress) {
            downLoadProgress(download);
        }
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        if (success) {
            success(responseObject);
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        if (failure) {
            failure(error);
        }
    }];
}

+ (NetworkStatus)GetAFNetworkStatus{
    
    //1.创建网络监测者
    AFNetworkReachabilityManager *manager = [AFNetworkReachabilityManager sharedManager];
    
    /*枚举里面四个状态  分别对应 未知 无网络 数据 WiFi
     typedef NS_ENUM(NSInteger, AFNetworkReachabilityStatus) {
     AFNetworkReachabilityStatusUnknown          = -1,      未知
     AFNetworkReachabilityStatusNotReachable     = 0,       无网络
     AFNetworkReachabilityStatusReachableViaWWAN = 1,       蜂窝数据网络
     AFNetworkReachabilityStatusReachableViaWiFi = 2,       WiFi
     };
     */
    
   __block NetworkStatus netWorkStatus;
    
    [manager setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
        //这里是监测到网络改变的block  可以写成switch方便
        //在里面可以随便写事件
        switch (status) {
            case AFNetworkReachabilityStatusUnknown:
                netWorkStatus = NetworkReachabilityStatusUnknown;
                break;
            case AFNetworkReachabilityStatusNotReachable:
                netWorkStatus = NetworkReachabilityStatusNotReachable;
                break;
                
            case AFNetworkReachabilityStatusReachableViaWWAN:
                netWorkStatus = NetworkReachabilityStatusReachableViaWWAN;
                break;
                
            case AFNetworkReachabilityStatusReachableViaWiFi:
                
                netWorkStatus = NetworkReachabilityStatusReachableViaWiFi;
                break;
                
            default:
                break;
        }
        
    }] ;
    
    return netWorkStatus;
}

+ (void)requestAddImgPOSTWithURLStr:(NSString *)url paramDic:(NSDictionary *)paramDic image:(UIImage *)image name:(NSString *)name success:(void (^)(id responseObject))success failure:(void (^)(NSError *error))failure{
    
    // 1.创建网络管理者
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.responseSerializer.acceptableContentTypes =  [NSSet setWithObjects:@"text/html",@"application/json",@"text/javascript",@"text/json",@"text/plain", nil];
    //请求图片,请求网页时需要加入这句,因为AFN默认的请求的是json
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    manager.requestSerializer = [AFHTTPRequestSerializer serializer];
    // 2.发送请求(字典只能放非文件参数)
    [manager POST:url parameters:paramDic constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
        NSData *imageData = UIImageJPEGRepresentation(image, 0.5);//进行图片压缩
        // 使用日期生成图片名称
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        formatter.dateFormat = @"yyyyMMddHHmmss";
        NSString *fileName = [NSString stringWithFormat:@"%@.png",[formatter stringFromDate:[NSDate date]]];
        
        // 上传图片，以文件流的格式
        // 任意的二进制数据MIMEType application/octet-stream
        // 特别注意，这里的图片的名字不要写错，必须是接口的图片的参数名字如我这里是file
        if (imageData!=nil) { // 图片数据不为空才传递
            [formData appendPartWithFileData:imageData name:name fileName:fileName mimeType:@"image/png"];
        }
    } progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:(NSJSONReadingMutableContainers) error:nil];
        if ([[dic objectForKey:@"status"]isEqualToString:@"success"]) {
            success(responseObject);
        }else{
            NSString *message = [responseObject objectForKey:@"message"];
            NSLog(@"messageImg == %@",message);
            
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        failure(error);
    }]; 
}

@end
