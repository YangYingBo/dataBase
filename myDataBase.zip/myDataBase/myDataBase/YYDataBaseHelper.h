//
//  YYDataBaseHelper.h
//  myDataBase
//
//  Created by Loser on 2017/5/8.
//  Copyright © 2017年 Mac. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YYDataBaseHelper : NSObject

- (instancetype)initWithDBName:(NSString *)name;
/**
 *  更新或者添加数据
 *
 *  @param model model
 */
- (BOOL)insertAndUpdataModelToDataBase:(id)model;
/**
 *  获取表中所有数据
 *
 *  @param model model
 *
 *  @return array
 */
- (NSArray *)selectAllModelFromeDataBase:(id)model;
/**
 *  根据指定属性  指定的数值  获取数据库中的数据
 *
 *  @param model    model
 *  @param property 指定属性
 *  @param values   指定数值
 *
 *  @return array
 */
- (NSArray *)selectModelFromDataBase:(id)model byProperty:(NSString *)property withPropertyValues:(NSString *)values;
/**
 *  删除指定属性指定内容的数据
 *
 *  @param model    model
 *  @param property 指定属性
 *  @param values   指定内容
 *
 *  @return 是否删除成功
 */
- (BOOL)deletaModelFromDataBase:(id)model byProperty:(NSString *)property andPropertyFromValues:(NSString *)values;

/**
 根据model名删除表

 @param model model
 */
- (void)deleteAllDataFrome:(id)model;

- (NSArray *)getModelAllProperty:(id)model;
@end
